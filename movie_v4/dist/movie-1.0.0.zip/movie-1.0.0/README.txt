newCheck.py
	从第一页开始检查，直到已解析过，最多解析10页
	结果保存到:Result_日期.txt
	暂无高清资源的电影保存到:WaitingRoom.txt(此可以手动修改，删去不想看的)

reCheck.py
	再次检查之前没有高清资源的电影
	更新:WaitingRoom.txt
	结果保存到:Wait_日期.txt