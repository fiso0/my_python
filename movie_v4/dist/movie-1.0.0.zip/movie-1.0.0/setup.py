from distutils.core import setup

setup(
    name = 'movie',
    version = '1.0.0',
    py_modules = ['mymovie'],
    author = 'fiso0',
    description = 'Parser of BTtiantang'
    )
